*******************************************************
*  Name      :  Khang Nguyen 
*  Student ID:  109370488           
*  Class     :  CSC 2421           
*  Due Date  :  Oct 18, 2018
*******************************************************


                 Read Me

*******************************************************
*  Description of the program
*******************************************************
This program simulates first in first serve in bank simulation
*******************************************************
*  Source files
*******************************************************

Name:  main.cpp
   Main program.  This is the driver program that calls sub-functions
   to input data, use the data and function to output approriate message.
Name: Associate.h
   Contains the definition for function that support readfile,
   process for customers come in only one line and process for customers
to come in in three lines

Name: Associate.cpp
   Define and implements that arival and departure time will be organized
Name: Teller.h
   Contains the definition for class Teller 
Name: Teller.cpp
   Define and implements class Teller
*******************************************************
*  Status of program
*******************************************************
   Extra credits 
   The program runs successfully.  
   
   The program was developed and tested on CLion g++.  It was 
   compiled, run, and tested on csegrid.ucdenver.pvt.

