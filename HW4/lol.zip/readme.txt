*******************************************************
*  Name      :  Khang Nguyen 
*  Student ID:  109370488           
*  Class     :  CSC 2421           
*  Due Date  :  Sep 20, 2018
*******************************************************


                 Read Me


*******************************************************
*  Description of the program
*******************************************************

*******************************************************
*  Source files
*******************************************************

Name:  main.cpp
   Main program.  This is the driver program that calls sub-functions
   to input data, use the data and function to output approriate message.

Name: MyVector.h
   Contains the definition for MyVecTor class
Name: MyVector.cpp
   Define and implements MyVector class. This class implements add element, remove element,
retrive size, check for empty and search a value in an object with class is MyVecTor.

   
*******************************************************
*  Status of program
*******************************************************
   The program runs successfully.  
   
   The program was developed and tested on CLion g++.  It was 
   compiled, run, and tested on csegrid.ucdenver.pvt.

