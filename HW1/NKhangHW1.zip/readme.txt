*******************************************************
*  Name      :  Khang Nguyen 
*  Student ID:  109370488           
*  Class     :  CSC 2421           
*  Due Date  :  August 30, 2018
*******************************************************


                 Read Me


*******************************************************
*  Description of the program
*******************************************************

The program "guess" let computer generates random number from 1 to n and
let player inputs data from keyboard. The program implements the data from user and
compares it to computer. The program will output approriate message according to player's guess

*******************************************************
*  Source files
*******************************************************

Name:  main.cpp
   Main program.  This is the driver program that calls sub-functions
   to input data, use the data and function to output approriate message.

Name:  guess.h
   Contains the declare function.
Name: guess.cpp
   Define functions.


   
*******************************************************
*  Status of program
*******************************************************

   The program runs successfully.  
   
   The program was developed and tested on CLion g++.  It was 
   compiled, run, and tested on csegrid.ucdenver.pvt.

