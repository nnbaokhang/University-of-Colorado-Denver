*******************************************************
*  Name      :  Khang Nguyen 
*  Student ID:  109370488           
*  Class     :  CSC 2421           
*  Due Date  :  Nov 18, 2018
*******************************************************


                 Read Me

*******************************************************
*  Description of the program
*******************************************************
This program is a simple spellchecker
*******************************************************
*  Source files
*******************************************************
Name:  main.cpp
   Main program.  This is the driver program that calls sub-functions
   to input data, use the data and function to output approriate message.
Name: hashTable.h
   Contains class for hashTable which is a data structure,
   also contain function to counting words and check if input is a legitimate word
Name: hashTable.cpp
   Define and implements hashTable class and checkFileWord and isString function

*******************************************************
*  Status of program
*******************************************************
   Extra credits 
   The program runs successfully.  
   
   The program was developed and tested on CLion g++.  It was 
   compiled, run, and tested on csegrid.ucdenver.pvt.

