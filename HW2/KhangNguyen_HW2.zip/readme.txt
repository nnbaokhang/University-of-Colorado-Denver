*******************************************************
*  Name      :  Khang Nguyen 
*  Student ID:  109370488           
*  Class     :  CSC 2421           
*  Due Date  :  Sep 6, 2018
*******************************************************


                 Read Me


*******************************************************
*  Description of the program
*******************************************************

*******************************************************
*  Source files
*******************************************************

Name:  main.cpp
   Main program.  This is the driver program that calls sub-functions
   to input data, use the data and function to output approriate message.

Name: ArrayBag.h
   Contains the definition for class ArrayBag
Name: ArrayBag.cpp
   Define and implements the ArrayBag class. This class allow to add, remove, get index
of an object. Also it implements + and - between two objects.
Name: SetFunctions.cpp
   Define and implements to get data from file
Name: SetFunctions.h
   Contains the definition of getintergerfromfile method
   
*******************************************************
*  Status of program
*******************************************************
   Extra credit
   The program runs successfully.  
   
   The program was developed and tested on CLion g++.  It was 
   compiled, run, and tested on csegrid.ucdenver.pvt.

