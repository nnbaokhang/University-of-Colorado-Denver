//
// Created by khang on 8/31/2018.
//

#ifndef HW2_ASSOCIATE_H
#define HW2_ASSOCIATE_H
#include<vector>
#include<fstream>
bool getIntsFromFile(std::ifstream &infile,std::vector<int> &vec);
void printValues(std::vector<int> set );

#endif //HW2_ASSOCIATE_H
