//
// Created by khang on 10/27/2018.
//

#ifndef DATABASE_MENUDRIVER_H
#define DATABASE_MENUDRIVER_H


void menu();
void menuSearch();
void submenuSearch();
void menuAdd();
void menuFile();
void menuDelete();
void menuModify();
#endif //DATABASE_MENUDRIVER_H
