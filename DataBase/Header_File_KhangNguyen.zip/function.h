//
// Created by khang on 11/1/2018.
//

#ifndef DATABASE_FUNCTION_H
#define DATABASE_FUNCTION_H
#include<iostream>
#include <vector>
#include "BSTree.h"
#include "BSTree.hpp"

bool addNewRecord(BSTree<GeneralData,string>& temptTree,GeneralData newRecord);
//Pre: Record is not yet exist in database
//Add new record into database
//Post: return 1 if successful add else 0
bool deleteRecord(BSTree<GeneralData,string>& temptTree,GeneralData record);
//Pre:Record is exist in database
//Delete existing record
//Post return 1 if successful delete else 0
bool modifyRecord(BSTree<GeneralData,string>& temptTree,GeneralData record);
//Pre:Record is exist in database
//Modify existing record
//Post return 1 if successful delete else 0
bool exactSearchRecord(BSTree<GeneralData,string>& temptTree,GeneralData record);
//Exact search every record in database
//Post return 1 if record is in database else 0
bool partialSearchRecord(BSTree<GeneralData,string>& temptTree,GeneralData record);
//Partial search every record in database
//Post return 1 if record is in database else 0
void sortRecordByField(BSTree<GeneralData,string>& temptTree, string field);
//Pre: Field must exist
//Post: database is sorted by field


#endif //DATABASE_FUNCTION_H
