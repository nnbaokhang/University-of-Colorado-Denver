*******************************************************
*  Name      :  Khang Nguyen 
*  Student ID:  109370488           
*  Class     :  CSC 2421           
*  Due Date  :  Sep 29, 2018
*******************************************************


                 Read Me

*******************************************************
*  Description of the program
*******************************************************
This program creates and implementation a linked list
*******************************************************
*  Source files
*******************************************************

Name:  main.cpp
   Main program.  This is the driver program that calls sub-functions
   to input data, use the data and function to output approriate message.

Name: LinkedList.h
   Contains the definition for LinkedList class
Name: LinkedList.cpp
   Define and implements LinkedList class. This class implements add node, remove node and output 
linked list   
*******************************************************
*  Status of program
*******************************************************
   Extra credits 
   The program runs successfully.  
   
   The program was developed and tested on CLion g++.  It was 
   compiled, run, and tested on csegrid.ucdenver.pvt.

