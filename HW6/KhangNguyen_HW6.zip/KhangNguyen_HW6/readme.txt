*******************************************************
*  Name      :  Khang Nguyen 
*  Student ID:  109370488           
*  Class     :  CSC 2421           
*  Due Date  :  Oct 4, 2018
*******************************************************


                 Read Me

*******************************************************
*  Description of the program
*******************************************************
This program creates and implementation a doubly linked list
*******************************************************
*  Source files
*******************************************************

Name:  main.cpp
   Main program.  This is the driver program that calls sub-functions
   to input data, use the data and function to output approriate message.

Name: DictEntry.h
   Contains the definition for DictEntry node and methods
Name: Dictionary.h
   Contains the definition for STL doubly linked list and methods
Name: Dictionary.cpp
   Define and implements STL doubly linked list and methods. This class implements add node to linked list
 and output to console and write to file
Name: DoublyLinkedList.h
   Contains the definition for doubly linked list class
Name: DoublyLinkedList.cpp
   Define and implements doubly linked list class. This class implements add node to linked list 
and output to console and write to file
*******************************************************
*  Status of program
*******************************************************
   Extra credits 
   The program runs successfully.  
   
   The program was developed and tested on CLion g++.  It was 
   compiled, run, and tested on csegrid.ucdenver.pvt.

